﻿package com.app.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.app.dao.AdminDao;
import com.app.model.Admin;

/**
 * 
 * @author lizhaoyi
 *
 */
public class AdminDaoImpl extends HibernateDaoSupport implements AdminDao {

	public void delAdmin(Admin admin) {
		// TODO Auto-generated method stub
		super.getHibernateTemplate().delete(admin);
	}

	public Admin getAdmin(int adm_autoid) {
		// TODO Auto-generated method stub
		List admins=super.getHibernateTemplate().find("from Admin admin where admin.adm_autoid='"+adm_autoid+"'");
		if(admins.size()>0){
			return (Admin)admins.get(0);
		}
		return null;
	}

	public List getAdmin(String adm_name, String adm_password) {
		// TODO Auto-generated method stub
		return super.getHibernateTemplate().find("from Admin admin where admin.adm_name='"+adm_name+"' and admin.adm_password='"+adm_password+"'");
		
	}

	public List getAdmins() {
		// TODO Auto-generated method stub
		List admins=super.getHibernateTemplate().find("from Admin admin");
		return admins;
	}

	public Integer saveAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return (Integer)super.getHibernateTemplate().save(admin);
	}

	public List getAdmin(String hql,int start,int limit){
		return super.getHibernateTemplate().getSessionFactory().openSession().createQuery(hql).setFirstResult(start).setMaxResults(limit).list();
	}
	
	public Long getCount(String hql){
		return (Long)super.getHibernateTemplate().getSessionFactory().openSession().createQuery(hql).uniqueResult();
	}
	
}
