﻿package com.app.dao;

import java.util.List;

import com.app.model.Admin;

/**
 * 
 * @author lizhaoyi
 *
 */
public interface AdminDao {
	//取出所有用户信息
	public List getAdmins();
	//取到相应用户信息，供删除用
	public Admin getAdmin(int id);
	//增加管理员信息
	public Integer saveAdmin(Admin admin);
	//删除用户信息（物理删除）,个人推荐逻辑删除
	public void delAdmin(Admin admin);
	//查询用户信息，供登录时用
	public List getAdmin(String name,String password);
	//查询用户信息，用于分页
	public List getAdmin(String hql,int start,int limit);
	//获取总数
	public Long getCount(String hql);

}
