package com.app.model;

import java.io.Serializable;

public class Admin implements Serializable {

	/**
	 * by Li Zhaoyi
	 */
	private static final long serialVersionUID = 1L;
	private Integer adm_autoid;
	private String adm_name;
	private String adm_sex;
	private String adm_account;
	private String adm_password;
	private String adm_age;
	private String adm_phone;
	private Integer flag;

	public Admin() {

	}

	public Admin(Integer adm_autoid, String adm_name, String adm_sex,String adm_account, String adm_password,
			String adm_age,String adm_phone,Integer flag) {
		this.adm_autoid = adm_autoid;
		this.adm_name = adm_name;
		this.adm_sex = adm_sex;
		this.adm_account = adm_account;
		this.adm_password = adm_password;
		this.adm_age = adm_age;
		this.adm_phone = adm_phone;
		this.flag = flag;
	}

	public Integer getAdm_autoid() {
		return adm_autoid;
	}

	public void setAdm_autoid(Integer adm_autoid) {
		this.adm_autoid = adm_autoid;
	}

	public String getAdm_name() {
		return adm_name;
	}

	public void setAdm_name(String adm_name) {
		this.adm_name = adm_name;
	}

	public String getAdm_sex() {
		return adm_sex;
	}

	public void setAdm_sex(String adm_sex) {
		this.adm_sex = adm_sex;
	}

	public String getAdm_account() {
		return adm_account;
	}

	public void setAdm_account(String adm_account) {
		this.adm_account = adm_account;
	}

	public String getAdm_password() {
		return adm_password;
	}

	public void setAdm_password(String adm_password) {
		this.adm_password = adm_password;
	}

	public String getAdm_age() {
		return adm_age;
	}

	public void setAdm_age(String adm_age) {
		this.adm_age = adm_age;
	}

	public String getAdm_phone() {
		return adm_phone;
	}

	public void setAdm_phone(String adm_phone) {
		this.adm_phone = adm_phone;
	}

	public Integer getFlag() {
		return flag;
	}

	public void setFlag(Integer flag) {
		this.flag = flag;
	}

	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	
}
