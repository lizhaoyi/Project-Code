﻿package com.app.service.impl;

import java.util.List;

import com.app.dao.AdminDao;
import com.app.model.Admin;
import com.app.service.AdminService;

public class AdminServiceImpl implements AdminService {

	private AdminDao adminDao;
	
	public void delAdmin(Admin admin) {
		// TODO Auto-generated method stub
		adminDao.delAdmin(admin);
	}

	public Admin getAdmin(int adm_id) {
		// TODO Auto-generated method stub
		return adminDao.getAdmin(adm_id);
	}

	public List getAdmin(String adm_name, String adm_password) {
		// TODO Auto-generated method stub
		return adminDao.getAdmin(adm_name, adm_password);
	}

	public List getAdmins() {
		// TODO Auto-generated method stub
		return adminDao.getAdmins();
	}

	public Integer addAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return (Integer) adminDao.saveAdmin(admin);
	}

	public AdminDao getAdminDao() {
		return adminDao;
	}

	public void setAdminDao(AdminDao adminDao) {
		this.adminDao = adminDao;
	}

	public List getAdmin(String hql,int start,int limit){
		return adminDao.getAdmin(hql, start, limit);
	}
	
	public Long getCount(String hql){
		return adminDao.getCount(hql);
	}

}
