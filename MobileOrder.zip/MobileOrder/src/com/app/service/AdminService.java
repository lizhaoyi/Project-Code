﻿package com.app.service;

import java.util.List;

import com.app.model.Admin;

/**
 * 
 * @author lizhaoyi
 *
 */
public interface AdminService {
	//取出所有管理员信息
	public List getAdmins();	
	//取到相应管理员信息，供删除用
	public Admin getAdmin(int adm_autoid);
	//增加管理员信息（设计为integer,为了调试，如果不需要的话，可以设置为void）
	public Integer addAdmin(Admin admin);
	//删除管理员信息（物理删除）,个人推荐逻辑删除
	public void delAdmin(Admin admin);
	//查询管理员信息，供登录时用
	public List getAdmin(String adm_name,String adm_password);
	//查询管理员信息，用于分页
	public List getAdmin(String hql,int start,int limit);
	//获取总数
	public Long getCount(String hql);
}
