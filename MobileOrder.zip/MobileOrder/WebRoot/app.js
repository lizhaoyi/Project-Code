//Ext加载配置
Ext.Loader.setConfig({
    //设置是否动态依赖加载功能
    enabled: true
});

Ext.application({
    name: 'APP',                  //设置路径名
    autoCreateViewport:false,     //是否动态创建在APP路径下VIEW文件下的Viewport.js文件
    appFolder: 'Application/app',//实际路径
    controllers: ['Main']         //执行路径下controller文件下的Main.js文件
});
