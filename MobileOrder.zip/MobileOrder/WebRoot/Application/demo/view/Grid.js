Ext.define('APP.view.Grid' , {

	extend: 'Ext.grid.Panel',	
	alias : 'widget.userlist',
	title : '学生信息列表',
	store: 'Users',	

	columns: [{
		header: '用户名',
		dataIndex: 'username',
		width:100
	},{
		header: '性别',
		dataIndex: 'usersex',
		width:100
	},{
		header: '年龄',
		dataIndex: 'userage',
		width:100
	},{
		header: '学校',
		dataIndex: 'school',
		width:100
	},{
		header: '邮箱',
		dataIndex: 'useremail',
		flex:1
	}],
	
	dockedItems: [{
        xtype: 'pagingtoolbar',
        store: 'Users',   
        dock: 'bottom',
        displayInfo: true
    }]
});