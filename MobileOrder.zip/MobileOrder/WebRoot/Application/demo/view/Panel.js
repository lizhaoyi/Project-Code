Ext.define('APP.view.Panel', {
    extend: 'Ext.panel.Panel'
});