Ext.define('APP.controller.Users', {
	extend: 'Ext.app.Controller',
	models: ['User'],
	stores: ['Users'],
	views: ['Panel', 'Grid'],
	init: function() {
		Ext.create('Ext.panel.Panel', {
			layout: 'fit',
			height: 300,
			width: 550,
			items: {
				xtype: 'userlist'
			},
			renderTo: Ext.getBody()
		});
	}
});