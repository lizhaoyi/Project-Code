Ext.define('APP.store.Users', {
	
	extend: 'Ext.data.Store',
	model: 'APP.model.User',
	autoLoad: true,
	
	pageSize: 8,
	/*proxy:{
	  type: 'ajax',
	  url: 'Application/demo/xml/user.xml',
	  reader:{
	     type: 'xml',
		 root  : 'users',
         record: 'user',
         successProperty: 'success',
		 totalProperty:'totalCount'
	  }
	}*/
	proxy: {
		type: 'ajax',
		url:'login?id=1',
		reader: {
			type: 'json',
			root: 'users',
			successProperty: 'success',
			totalProperty:'totalCount'
		}
	}
});