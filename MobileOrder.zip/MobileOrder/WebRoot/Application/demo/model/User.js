Ext.define('APP.model.User', {
	
	extend: 'Ext.data.Model',
	fields: ['id', 'username', 'useremail','password','usersex','school','userage','flag']
});