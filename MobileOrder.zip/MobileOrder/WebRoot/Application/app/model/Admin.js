Ext.define('APP.model.Admin', {
	
	extend: 'Ext.data.Model',
	fields: ['adm_autoid', 'adm_name', 'adm_sex','adm_account','adm_password','adm_age','adm_phone','flag']
});