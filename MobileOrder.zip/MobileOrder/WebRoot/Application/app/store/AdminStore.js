//定义管理员信息数据模型
Ext.define('APP.store.AdminModel',{
    extend: 'Ext.data.Model',
    model: 'APP.model.Admin',
    fields: [
         {name: 'Adm_autoid',mapping: 'adm_autoid'},//编号
                'Adm_name',             //名字
                'Adm_sex',              //性别
                'Adm_account',          //账号
                'Adm_password',         //密码
                'Adm_age',              //年龄
                'Adm_phone',            //电话
                'Flag',             //是否可以删除
                'Delete'            //是否已经删除
    ]
});
//定义管理员信息数据源
Ext.define('APP.store.AdminStore',{
    extend: 'Ext.data.Store',
    model: 'APP.model.Admin',//读取Admin模型
    //model: 'APP.store.AdminModel',//读取AdminModel模型
    pageSize: 20,//每次最多显示20页(只有动态生成的数据才会执行)
    /*proxy: {
       type: 'ajax',
       url: './Application/app/xml/admin-data.xml',
       reader: {
           type: 'xml',//读取xml类型的数据
           root: 'admins',//数据的根目录名
           record: 'admin',//每条记录的目录名
           successProperty: 'success',//是否读到数据
		   totalProperty:'totalCount'//记录总条数
       }
    },*/
    proxy: {
		type: 'ajax',
		url:'admin?type=queryall',
		reader: {
			type: 'json',
			root: 'admins',
			successProperty: 'success',
			totalProperty:'totalCount'
		}
	}, 	
    autoLoad: true//自动加载数据
});