//定义客户信息数据模型
Ext.define('APP.store.Client',{
    extend: 'Ext.data.Model',
    fields: [
         {name: 'Id',mapping: 'Id'},//账号
                'Password',         //密码
                'Name',             //姓名
                'Sex',              //性别
         { name: 'Date', type: 'date', dateFormat: 'n/j/Y'},             //出身日期
                'Idcard',           //身份证
                'Phone',            //联系电话
                'Email',            //邮箱
                'Address',          //居住地址
         { name: 'Registration', type: 'date', dateFormat: 'n/j/Y'},     //注册日期
         { name: 'Delete', type: 'bool'}            //是否已经删除
    ]
    
});
//定义客户信息数据源
Ext.define('APP.store.ClientStore',{
    extend: 'Ext.data.Store',
    autoDestroy: true, //当grid被Destroy时，store就自动被Destroy
    model: 'APP.store.Client',//读取RestaurantModel模型
    pageSize: 20,//每次最多显示20页(只有动态生成的数据才会执行)
    proxy: {
       type: 'ajax',
       url: './Application/app/xml/client-data.xml',
       reader: {
           type: 'xml',//读取xml类型的数据
           root: 'clients',//数据的根目录名
           record: 'client',//每条记录的目录名
           successProperty: 'success',//是否读到数据
		   totalProperty:'totalCount'//记录总条数
       }
    }, 
    sorters: [{//按照注册时间排序
        property: 'Registration',
        direction: 'ASC'
     }],
    autoLoad: true//自动加载数据
});