//定义餐厅信息数据模型
Ext.define('APP.store.Restaurant',{
    extend: 'Ext.data.Model',
    fields: [
         {name: 'Id',mapping: 'Id'},//账号
                'Password',         //密码
                'Name',             //名称
                'Address',          //地址
                'Coordinate',       //坐标
                'Map',              //详细地图路径
                'Phone',            //电话
                'Businesstime',     //营业时间
                'Consumption',      //人均消费
                { name: 'Registration', type: 'date', dateFormat: 'n/j/Y'},     //注册日期
                { name: 'Delete', type: 'bool'}            //是否已经删除
    ]
});
//定义餐厅信息数据源
Ext.define('APP.store.RestaurantStore',{
    extend: 'Ext.data.Store',
    model: 'APP.store.Restaurant',//读取RestaurantModel模型
    pageSize: 20,//每次最多显示20页(只有动态生成的数据才会执行)
    proxy: {
       type: 'ajax',
       url: './Application/app/xml/restaurant-data.xml',
       reader: {
           type: 'xml',//读取xml类型的数据
           root: 'restaurants',//数据的根目录名
           record: 'restaurant',//每条记录的目录名
           successProperty: 'success',//是否读到数据
		   totalProperty:'totalCount'//记录总条数
       }
    }, 
    autoLoad: true//自动加载数据
});