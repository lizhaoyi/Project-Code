//定义后台框架低端Bottom类
Ext.define('APP.view.Bottom',{
    extend: 'Ext.Toolbar',
    initComponent : function(){
        Ext.apply(this,{
            id: 'bottom',
            //frame:true,
            region: "south",
            height:23,
            items:["当前用户：Demo",'->',"技术支持:<a href='http://www.mhzg.net' target='_blank' style='text-decoration:none;'><font color='#0000FF'>http://www.mhzg.net</font></a>&nbsp;&nbsp;"]
        });
        this.callParent(arguments);
    }
});
