//定义后台框架左边菜单
Ext.define('APP.view.Menu',{
    extend: 'Ext.tree.Panel',
    initComponent : function(){
        Ext.apply(this,{
            id: 'menu-panel',
            title: '系统菜单',
            iconCls: 'icon-menu',  //设置class属性
            margins: '0 0 -1 1',   //边距
            region: 'west',
            lines: false,          //设置是否有虚线
            store: treeStore,      //读取数据
            border: true,          //边框
            split: true,           //分隔线
            animate: true,         //鼠标在菜单栏移动时有阴影
            width: 170,
            minSize: 170,
            maxSize: 250,
            rootVisible: false,    //不显示root节点
            containerScroll: true, //显示滚动条
            autoScroll: true,     //拉动滚动条时会滚动
            collapsible: true,    //收缩
            listeners: {
                 select: {        //选择事件
                     fn:changeTabPage //执行函数,改变tabPanel页面
                 }
            }     
       });
       this.callParent(arguments);
    }
});
//创建树的数据
var treeStore = Ext.create('Ext.data.TreeStore', {
        root: {
               expanded: true
        },
        proxy: {
            type: 'ajax',
            url: './Application/app/server/tree-data.json'//读取树的JSON数据
        }
});
//更换面板函数
function changeTabPage(selModel, record){
     if (record.get('leaf')) {
            Ext.getCmp('content-panel').layout.setActiveItem(record.getId() + '-panel');
     }
}