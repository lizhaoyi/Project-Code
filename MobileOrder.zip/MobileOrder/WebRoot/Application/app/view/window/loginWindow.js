/*定义管理员登录界面的loginWindow类*/
var win;//定义全局变量代表窗口
Ext.define('APP.view.window.loginWindow',{ 
    extend:'Ext.window.Window', 
    alias: 'widget.loginForm', 
    requires: ['Ext.form.*','APP.view.window.CheckCode'], 
    initComponent:function(){ 
        win = this;
        var checkcode = Ext.create('APP.view.window.CheckCode',{ 
            //cls : 'key', 
            fieldLabel : '验证码', 
            name : 'CheckCode', 
            id : 'CheckCode',
            minimizable:true, 
            allowBlank : false, 
            isLoader:true, 
            blankText : '验证码不能为空', 
            codeUrl: 'image.jsp', 
            width : 160 
        }); 
        var form = Ext.widget('form',{ 
            border: false, 
            bodyPadding: 10, 
            fieldDefaults: { 
                labelAlign: 'left', 
                labelWidth: 55, 
                labelStyle: 'font-weight:bold'
            }, 
            defaults: { 
                margins: '0 0 10 0'
            }, 
            items:[{ 
                xtype: 'textfield', 
                fieldLabel: '用户名', 
                blankText : '用户名不能为空', 
                allowBlank: false, 
                width:240 
            },{ 
                xtype: 'textfield', 
                fieldLabel: '密&nbsp;&nbsp;&nbsp;码', 
                allowBlank: false, 
                blankText : '密码不能为空', 
                width:240, 
                inputType : 'password'  
            },checkcode], 
            buttons:[{ 
                text:'登录', 
                handler:function(){
                        //利用submit()进行数据交互
		                loginForm.getForm().submit( {
						url : 'Manager?type=login',
						success : function() {
							JsHelper.OK("登录成功!", function() {
								window.location = 'HomePage.jsp';
							});
						},
						failure : function() {
							JsHelper.OK("登录失败，请核对数据!", function() {
								loginForm.form.reset();
							});
						}
					})      
                } 
            },{ 
                text:'取消', 
                handler:function(){ 
                     win.hide();
                } 
            }] 
        }); 
        Ext.apply(this,{ 
            height: 160, 
            width: 280, 
            title:'用户登陆', 
            closeAction: 'hide', 
            closable : false,  
            iconCls: 'icon-login', 
            layout: 'fit', 
            modal : true,  
            plain : true, 
            resizable: false, 
            items:form 
        }); 
        this.callParent(arguments); 
    } 
});
