var treepanels = [];  //系统菜单中功能的界面集合
//定义后台框架显示TabPanel类
Ext.define('APP.view.ContentPanel',{
    extend: 'Ext.panel.Panel',
    requires: [
       'APP.view.treepanel.HomePanel',
       'APP.view.treepanel.InformationPanel',
       'APP.view.treepanel.PayoffPanel',
       'APP.view.treepanel.RestaurantPanel',
       'APP.view.treepanel.ClientCommentPanel',
       'APP.view.treepanel.AdminPanel'
    ],
    initComponent : function(){
        this.pushTreePanels();//向treepanels里存放系统菜单中功能的界面
        Ext.apply(this,{
            id: 'content-panel',
            region: 'center', 
            layout: 'card',
            activeItem: 0,  //默认第一个tabPanel页面
            border: false,
            plain: false,
            items: treepanels 
        });
        this.callParent(arguments);
    },
    //存放treepanel函数
    pushTreePanels: function (){
       treepanels.push(Ext.create('APP.view.treepanel.HomePanel'));//主页的panel
       treepanels.push(Ext.create('APP.view.treepanel.InformationPanel'));//信息管理的panel
       treepanels.push(Ext.create('APP.view.treepanel.PayoffPanel'));//支付管理的panel
       treepanels.push(Ext.create('APP.view.treepanel.RestaurantPanel'));//餐厅管理的panel
       treepanels.push(Ext.create('APP.view.treepanel.ClientCommentPanel'));//客户点评管理的panel
       treepanels.push(Ext.create('APP.view.treepanel.AdminPanel'));//管理员信息管理的panel
       
    }
});
