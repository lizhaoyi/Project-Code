﻿//定义管理员信息管理的panel
Ext.define('APP.view.treepanel.AdminPanel',{
    extend: 'Ext.panel.Panel',
    requires: [ 
       'APP.view.treepanel.AdminPanelItems.AdminGrid'
    ],
    initComponent : function(){
        Ext.apply(this,{
            id: 'admin-panel',
            title: '管理员信息管理',
            iconCls: 'icon-adminManagement-16',
            layout: 'fit',
            items: Ext.create('APP.view.treepanel.AdminPanelItems.AdminGrid')//创建AdminGrid
            
       });
       this.callParent(arguments);
    }
});