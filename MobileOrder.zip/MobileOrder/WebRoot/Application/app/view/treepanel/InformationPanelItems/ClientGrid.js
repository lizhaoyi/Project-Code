var clientstore = {}; //全局变量（为ClientStore的对象）
var clientgrid; //全局变量（为ClientGrid的对象）
/*创建行编辑对象*/
var rowEditing = Ext.create('Ext.grid.plugin.RowEditing', {
     clicksToMoveEditor: 1, //选择要编辑的行，点击就可以编辑
     autoCancel: false, //改变新的行，就自动取消对旧的行的编辑
     errorSummary: false //取弹出错误框(该框中的消息是英语的)
});

//改变性别的颜色（红男、绿女）
function sex(val){
    if(val == "男"){
       return '<span style="color:red;">' + val + '</span>';
    }else if(val == "女"){
       return '<span style="color:green;">' + val + '</span>';
    }
    return val;
}

//隐藏密码
function password(val){
    var len = val.length;//获取密码的长度
    val = '';//将密码先置为空串
    while(len){
        val += '*';//按照密码的长度显示相同长度的'*'
        len -= 1;
    }
    return val;
}

/*定义显示客户信息的ClientGrid类*/
Ext.define('APP.view.treepanel.InformationPanelItems.ClientGrid',{
    extend: 'Ext.grid.Panel',
    requires: [
        'APP.store.ClientStore'
    ],
    initComponent : function(){
        clientgrid = this;  //将ClientGrid创建的对象赋值给clientgrid
        this.createStore(); //创建gridPanel的store
        Ext.apply(this,{
            store: clientstore, //设置grid的store
            border: false, //设置grid没边框
            columns: [
                Ext.create('Ext.grid.RowNumberer'),//显示行数
                {header: '账号', width: 100, dataIndex: 'Id', sortable: true, 
                 editor:{//有editor才可以编辑
                     allowBlank: false,
                     blankText: '账号输入不能为空'
                }},
                {header: '密码', width: 100, dataIndex: 'Password', sortable: false, renderer: password,//渲染到password函数
                 editor: {
                     xtype: 'textfield',
                     allowBlank: false,
                     blankText: '密码输入不能为空',
		             inputType: 'password' //编辑时为密码输入框
                      
                 }},
                {header: '姓名', width: 80, dataIndex: 'Name', sortable: true, 
                 editor: {
                     allowBlank: false,
                     blankText: '姓名输入不能为空'
                 }},
                {header: '性别', width: 60, dataIndex: 'Sex', sortable: false, renderer: sex,//渲染到sex函数
                 editor: {
                     xtype: 'combobox',//编辑时为下拉框
                     store: Ext.create('Ext.data.ArrayStore', {
                         fields: ['sex'],
                         data: ['男','女'] 
                     }),
                     editable: false,
                     valueField: 'sex',
                     displayField: 'sex'    
                }},
                {header: '出生日期', width: 110, dataIndex: 'Date', sortable: false, xtype: 'datecolumn', 
                 editor: {
                     xtype: 'datefield',//编辑时为日期框
                     allowBlank: false,
                     editable: false,
                     format: 'm/d/Y',
                     minValue: '01/01/1929',
                     maxValue: Ext.Date.format(new Date(), 'm/d/Y')
                 }},
                {header: '身份证', width: 150, dataIndex: 'Idcard', sortable: false, 
                 editor: {
                     allowBlank: false,
                     blankText: '身份证输入不能为空' 
                }},
                {header: '联系电话', width: 110, dataIndex: 'Phone', sortable: false, 
                 editor: {
                     allowBlank: true
                 }},
                {header: '邮箱', width: 130, dataIndex: 'Email', sortable: false, 
                 editor: {
                     allowBlank: true,
                     vtype: 'email',//编辑时要符合邮箱格式
                     emailText: "邮箱格式不正确，正确邮箱格式(user@example.com)"
                 }},
                {header: '地址', width: 100, dataIndex: 'Address', sortable: false, 
                 editor: {
                     allowBlank: true
                 }},
                {header: '注册日期', flex: 1, dataIndex: 'Registration', sortable: true, xtype: 'datecolumn', format:'Y-m-d'},   
            ], 
            columnLines: true,//显示列线
            dockedItems: [ {
                dock: 'top',
                xtype: 'toolbar', //工具条（位置在顶端）
                items: ['搜 索：',{
                        xtype: 'triggerfield',
                        width: 120, //搜索条的长度
                        triggerCls: 'x-form-search-trigger',
                        onTriggerClick: this.Search
                       },'-',{
                        xtype: 'button',
                        text: '添加',
                        cls: 'client-add', //按钮的CSS
                        width: 60, //按钮的长度
                        handler: this.Add
                       }, {
                        itemId: 'removeClient',
                        xtype: 'button',
                        text: '删除',
                        cls: 'client-delete', //按钮的CSS
                        width: 60, //按钮的长度
                        handler: this.Delete       
                     }]
            },{
               dock: 'bottom',
               xtype: 'pagingtoolbar', //分页条（位置在底端）
               store: clientstore, //读取数据
               displayInfo: true,
               displayMsg: '显示 {0} - {1} 条，共计 {2} 条', //有数据时的显示格式
               emptyMsg: '没有数据'  //没有数据时的显示
           }],
           plugins: [rowEditing]//引入行编辑对象
       });
       this.callParent(arguments);
       this.on('edit', this.onEdit, this);//登记编辑事件
    },

    /*创建store方法*/
    createStore: function(){
          clientstore = Ext.create('APP.store.ClientStore'); //创建ClientStore对象
    },
        
    /*编辑方法*/
    onEdit: function(e){
        Ext.MessageBox.alert("提示",e.record.get("Id")+"");
        //e.record.commit();
    },
    
    /*查找Client方法*/
    Search: function(){
        var searchValue = this.getValue();//获取搜索框的值（这里的this是指triggerfield）
        Ext.MessageBox.alert('搜索当前的值',searchValue);
    },
    
    /*添加Client方法*/
    Add: function(){
		rowEditing.cancelEdit();//取消当前编辑
		/*按照Client数据模型创建数据对象*/
		var r = Ext.ModelManager.create({
		    Id: 'Demo',
		    Password: '123456',
		    Name: 'New Guy',
		    Sex: '男',
		    Date: new Date(),
		    Idcard: '445202************',
		    Phone: '',
		    Email: 'new@sencha-test.com',
		    Address: '',
		    Registration: new Date()
	    },'APP.store.Client');
		clientstore.insert(0,r);//插入新记录到storez中的第一行
		rowEditing.startEdit(0,0);//编辑第一行 
    },

    /*删除Client方法*/
    Delete: function(){
        var sm = clientgrid.getSelectionModel();//选择模型
        if(clientstore.getCount() > 0){//有记录时执行
            rowEditing.cancelEdit();//取消当前编辑
            clientstore.remove(sm.getSelection());//删除选中的记录
            if(clientstore.getCount() > 0){sm.select(0);}//如果还有记录，移到下一条记录
        }else{
           Ext.MessageBox.alert("提示","请选择要删除的记录！");
        }
    }   
});