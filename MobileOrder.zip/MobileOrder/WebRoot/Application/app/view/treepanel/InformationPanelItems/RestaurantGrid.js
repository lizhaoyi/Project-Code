var restaurantstore = {}; //全局变量（为RestaurantStore的对象）
var restaurantgrid; //全局变量（为RestaurantGrid的对象）

/*定义显示餐厅信息的RestaurantGrid类*/
Ext.define('APP.view.treepanel.InformationPanelItems.RestaurantGrid' ,{
    extend: 'Ext.grid.Panel',
    requires: [
       'APP.store.RestaurantStore'
    ],
    initComponent : function(){
        restaurantgrid = this;
        this.createStore(); //创建gridPanel的store 
        Ext.apply(this,{
            store: restaurantstore, //设置grid的store
            border: false, //设置grid没边框
            /*显示grid的列名*/
            columns: [
                Ext.create('Ext.grid.RowNumberer'),//显示行数
                {text: '账号', width: 100, dataIndex: 'Id', sortable: true},
                {text: '密码', width: 100, dataIndex: 'Password', sortable: false},
                {text: '名称', width: 150, dataIndex: 'Name', sortable: true},
                {text: '地址', width: 100, dataIndex: 'Address', sortable: false},
                {text: '坐标', width: 70, dataIndex: 'Coordinate', sortable: false},
                {text: '详细地图路径', width: 90, dataIndex: 'Map', sortable: false},
                {text: '联系电话', width: 100, dataIndex: 'Phone', sortable: false},
                {text: '营业时间', width: 100, dataIndex: 'Businesstime', sortable: false},
                {text: '人均消费', width: 80, dataIndex: 'Consumption', sortable: false},
                {text: '注册日期', flex: 1, dataIndex: 'Registration', sortable: true, xtype: 'datecolumn', format:'Y-m-d'},
                {xtype:'actioncolumn', 
                 width: 50,
                 items: [{
                          icon: 'Application/app/images/RestaurantGrid/restaurant-modify.png',  
                          tooltip: '修改',
                          handler: this.Modify
                        },{
                          icon: 'Application/app/images/RestaurantGrid/restaurant-delete.png', 
                          tooltip: '删除',
                          handler: this.Delete
                        }]
                 }], 
            columnLines: true,//列是否有线   	
	        dockedItems: [ {
            dock: 'top',
            xtype: 'toolbar', //工具条（位置在顶端）
            items: ['搜 索：',{
                xtype: 'triggerfield',
                width: 120, //搜索条的长度
                triggerCls: 'x-form-search-trigger',
                onTriggerClick: this.Search
              },'->',{
                xtype: 'button',
                text: '添加',
                cls: 'restaurant-add', //按钮的CSS
                width: 55, //按钮的长度
                handler: this.Add
              }]
           },{
                 dock: 'bottom',
                 xtype: 'pagingtoolbar', //分页条（位置在底端）
                 store: restaurantstore, //读取数据
                 displayInfo: true,
                 displayMsg: '显示 {0} - {1} 条，共计 {2} 条', //有数据时的显示格式
                 emptyMsg: '没有数据'  //没有数据时的显示
            }]
            
    });
    this.callParent(arguments);
    },
    
    /*创建store方法*/
    createStore: function(){
          restaurantstore = Ext.create('APP.store.RestaurantStore'); //创建RestaurantStore对象
    },
    
    /*查找restaurant方法*/
    Search: function(){
       var searchValue = this.getValue();//获取搜索框的值（这里的this是指triggerfield）
       Ext.MessageBox.alert('搜索当前的值',searchValue);
    },
    
    /*添加Restaurant方法*/
    Add: function(){
		
    },
    
    /*修改Restaurant方法*/
    Modify: function(grid, rowIndex, colIndex){
        var rec = grid.getStore().getAt(rowIndex);
        Ext.MessageBox.alert('提示', rec.get('Id'));    
	},
    
    /*删除Restaurant方法*/
    Delete: function(grid, rowIndex, colIndex){
        var rec = grid.getStore().getAt(rowIndex);
        Ext.MessageBox.alert('提示', rec.get('Id'));    
    }   
});
