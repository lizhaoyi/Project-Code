//定义信息管理的TabPanel类
Ext.define('APP.view.treepanel.InformationPanelItems.InformationTab',{
    extend: 'Ext.tab.Panel',
    requires: [ 
       'APP.view.treepanel.InformationPanelItems.ClientGrid',
       'APP.view.treepanel.InformationPanelItems.RestaurantGrid'
    ],
    initComponent : function(){
        var clientContent = "管理客户的信息，包括添加、修改、删除";//客户信息的内容
        var restaurantContent = "管理餐厅的信息，包括添加、修改、删除";//餐厅信息的内容
        Ext.apply(this,{
            items: [{title: '客户信息',
                     layout: 'fit',
                     tabConfig: {tooltip: clientContent},//鼠标指时会显示该功能的主要信息
                     items: Ext.create('APP.view.treepanel.InformationPanelItems.ClientGrid')
                    },{
                     title: '餐厅信息',
                     layout: 'fit',
                     tabConfig: {tooltip: restaurantContent},//鼠标指时会显示该功能的主要信息
                     items: Ext.create('APP.view.treepanel.InformationPanelItems.RestaurantGrid')//创建RestaurantGrid
                    }
            ] 
       });
       this.callParent(arguments);
    }
});