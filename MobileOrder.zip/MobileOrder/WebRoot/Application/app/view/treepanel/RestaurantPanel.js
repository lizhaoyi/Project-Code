//定义餐厅管理的panel
Ext.define('APP.view.treepanel.RestaurantPanel',{
    extend: 'Ext.panel.Panel',
    initComponent : function(){
        Ext.apply(this,{
            id: 'restaurant-panel',
            title: '餐厅管理',
            iconCls: 'icon-restaurantManagement-16',
            layout: 'fit',
            html: '<h1>界面未编写</h1>'
       });
       this.callParent(arguments);
    }
});