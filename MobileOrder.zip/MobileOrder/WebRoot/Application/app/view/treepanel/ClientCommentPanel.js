//定义客户点评管理的panel
Ext.define('APP.view.treepanel.ClientCommentPanel',{
    extend: 'Ext.panel.Panel',
    initComponent : function(){
        Ext.apply(this,{
            id: 'clientComment-panel',
            title: '客户点评管理',
            iconCls: 'icon-clientCommentManagement-16',
            layout: 'fit',
            html: '<h1>界面未编写</h1>'
       });
       this.callParent(arguments);
    }
});