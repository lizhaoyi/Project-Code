﻿var adminstore = {}; //全局变量（为adminstore的对象）
var admingrid; //全局变量（为AdminGrid的对象）

/*定义显示管理员信息的AdminGrid类*/
Ext.define('APP.view.treepanel.AdminPanelItems.AdminGrid' ,{
    extend: 'Ext.grid.Panel',
    model: 'APP.model.Admin',
    requires: [
       'APP.store.AdminStore',
       'APP.view.treepanel.AdminPanelItems.WindowForm'
    ],
    initComponent : function(){
        admingrid = this;
        this.createStore(); //创建gridPanel的store 
        Ext.apply(this,{
            store: adminstore, //设置grid的store
            border: false, //设置grid没边框
            /*显示grid的列名*/
            columns: [
                {text: '编号', width: 120, dataIndex: 'adm_autoid', sortable: true},
                {text: '姓名', width: 120, dataIndex: 'adm_name', sortable: false},
                {text: '性别', width: 90, dataIndex: 'adm_sex', sortable: true},
                {text: '账号', width: 150, dataIndex: 'adm_account', sortable: true},
                {text: '密码', width: 150, dataIndex: 'adm_password', sortable: false},
                {text: '年龄', width: 120, dataIndex: 'adm_age', sortable: true},
                {text: '电话', flex: 1, dataIndex: 'adm_phone', sortable: false}   //flex是填满最后一格     
            ],    	
	        dockedItems: [ {
            dock: 'top',
            xtype: 'toolbar', //工具条（位置在顶端）
            items: ['搜 索：',{
                xtype: 'triggerfield',
                width: 120, //搜索条的长度
                triggerCls: 'x-form-search-trigger',
                onTriggerClick: this.Search
              },'->',{
                xtype: 'button',
                text: '添加',
                cls: 'admin-add', //按钮的CSS
                width: 60, //按钮的长度
                handler: this.Add
              },'-',{
                xtype: 'button',
                text: '修改',
                cls: 'admin-modify', //按钮的CSS
                width: 60, //按钮的长度
                handler: this.Modify
              },'-',{
                xtype: 'button',
                text: '删除',
                cls: 'admin-delete', //按钮的CSS
                width: 60, //按钮的长度
                handler: this.Delete       
              }]
           },{
                 dock: 'bottom',
                 xtype: 'pagingtoolbar', //分页条（位置在底端）
                 store: adminstore, //读取数据
                 displayInfo: true,
                 displayMsg: '显示 {0} - {1} 条，共计 {2} 条', //有数据时的显示格式
                 emptyMsg: '没有数据'  //没有数据时的显示
            }],
            
    });
    this.callParent(arguments);
    },
    
    /*创建store方法*/
    createStore: function(){
          adminstore = Ext.create('APP.store.AdminStore'); //创建AdminStore对象
    },
    
    /*查找Admin方法*/
    Search: function(){
       var searchValue = this.getValue();//获取搜索框的值（这里的this是指triggerfield）
       Ext.MessageBox.alert('搜索当前的值',searchValue);
    },
    
    /*添加Admin方法*/
    Add: function(){
		 Ext.onReady(function() {
		 var windowform = Ext.create('APP.view.treepanel.AdminPanelItems.WindowForm'); //创建WindowForm对象
		     var win = Ext.create('Ext.window.Window', {
		                   title: '管理员注册',
		                   width: 200,
		                   height: 230,
		                   minWidth: 300,
		                   minHeight: 200,
		                   iconCls: 'admin-add', //图标名
		                   layout: 'fit',
		                   //plain: true,
		                   items: windowform,
		                   buttons: [{
		                      text: '确定',
		                      handler:function(){
								var value;
								if (windowform.getComponent('adm_sex').getValue())
									value = '男';
								else
									value = '女';
                                  Ext.Ajax.request({
								      url : 'admin?type=add',
											method : "post",
											success : function(response, opts) {
												if (response.responseText) {
													adminstore.load();
													Ext.MessageBox.alert("提示","添加成功!");
												} else {
													Ext.MessageBox.alert("警告","帐户已存在、或密码不对应、不允许空白,操作失败!");
												}
											},
											failure: function() {
												Ext.MessageBox.alert("警告","发送到后台失败，请重新检查发送是否正常!")
											},
											params: {
												adm_account : windowform.getComponent('adm_account').getValue(),
												adm_password : windowform.getComponent('adm_password').getValue(),
												adm_name : windowform.getComponent('adm_name').getValue(),
												adm_age : windowform.getComponent('adm_age').getValue(),
												adm_sex : value,
												adm_phone : windowform.getComponent('adm_phone').getValue()
											}
										});
		                      }
		                   },{
		                      text: '取消',
		                      handler:function(){win.hide();}
		                   }]
		    }).show();
	    });
    },
    
    /*修改Admin方法*/
    Modify: function(){
            var records = admingrid.getSelectionModel().getSelection();//选中的记录集
		    if(records.length == 0){// 判断有没有选中行
			   Ext.Msg.alert('提示', '你还没有选择要操作的记录!');
			}else{
			   Ext.onReady(function() {
			       var windowform = Ext.create('APP.view.treepanel.AdminPanelItems.WindowForm'); //创建WindowForm对象
			       windowform.getComponent('adm_account').setValue(records[0].get("adm_account")); //获得记录的账号值
			       windowform.getComponent('adm_password').setValue(records[0].get("adm_password")); //获得记录的密码值
			       windowform.getComponent('adm_name').setValue(records[0].get("adm_name")); //获得记录的管理员姓名值
			       windowform.getComponent('adm_age').setValue(records[0].get("adm_age")); //获得记录的年龄值
			       windowform.getComponent('adm_sex').setValue(records[0].get("adm_sex")); //获得记录的性别值
			       windowform.getComponent('adm_phone').setValue(records[0].get("adm_phone")); //获得记录的电话值
				   var win = Ext.create('Ext.window.Window', {
						         title: '管理员信息修改',
						         width: 200,
						         height: 230,
						         minWidth: 300,
						         minHeight: 200,
						         iconCls: 'admin-modify', //图标名
						         layout: 'fit',
						         //plain: true,
						         items: windowform,				
						         buttons: [{
						                    text: '确定'
						                 },{
						                    text: '取消',
						                    handler:function(){win.hide();}
						                }]
						    }).show(); 
			  });
		   }
	},
    
    /*删除Admin方法*/
    Delete: function(){
        var records = admingrid.getSelectionModel().getSelection();//选中的记录集
        Ext.MessageBox.alert('显示选中记录的编号',records[0].get("adm_autoid")+"");       
    }   
});
