var adminstore = {};//全局变量adminstore
var admingrid;
var modifyform;
var modifywin;
/*定义显示管理员信息的AdminGrid类*/
Ext.define('APP.view.treepanel.AdminPanelItems.AdminGrid' ,{
    extend: 'Ext.grid.Panel',
    requires: [
       'APP.store.AdminStore'
    ],
/**
    stripeRows : true, // 斑马线
    selModel : new Ext.grid.RowSelectionModel({
		singleSelect : true
	}),// 只允许选中一行
	trackMouseOver : true,
	frame : true,
    listeners : {
	"rowclick" : function() {
		var row = admingrid.getSelectionModel().getSelection();
		modifyform.getForm().reset();
		modifyform.getForm().loadRecord(row[0]);
		},
	"rowdblclick" : function() {
		row = admingrid.getSelectionModel().getSelection();
		modifyform.getForm().reset();
		modifyform.getForm().loadRecord(row[0]);
		modifywin.show();
		}
			    },
*/
    initComponent : function(){
        admingrid = this;
        this.createStore();//创建gridPanel的store
        Ext.apply(this,{
            store: adminstore,//设置grid的store
            border: false,//设置grid没边框
            /*显示grid的列名*/
            columns: [
                {text: '编号', width: 120, dataIndex: 'Id', sortable: true},
                {text: '姓名', width: 120, dataIndex: 'Name', sortable: false},
                {text: '性别', width: 90, dataIndex: 'Sex', sortable: true},
                {text: '账号', width: 150, dataIndex: 'Account', sortable: true},
                {text: '密码', width: 150, dataIndex: 'Password', sortable: false},
                {text: '年龄', width: 120, dataIndex: 'Age', sortable: true},
                {text: '电话', flex: 1, dataIndex: 'Phone', sortable: false}        
            ],    	
	        dockedItems: [ {
            dock: 'top',
            xtype: 'toolbar',//工具条（位置在顶端）
            items: ['搜 索：',{
                xtype: 'triggerfield',
                width: 120,//搜索条的长度
                triggerCls: 'x-form-search-trigger',
                onTriggerClick: this.Search
              },'->',{
                xtype: 'button',
                text: '添加',
                cls: 'admin-add',//按钮的CSS
                width: 60,//按钮的长度
                handler: this.Add
              },'-',{
                xtype: 'button',
                text: '修改',
                cls: 'admin-modify',//按钮的CSS
                width: 60,//按钮的长度
                handler: this.Modify
              },'-',{
                xtype: 'button',
                text: '删除',
                cls: 'admin-delete',//按钮的CSS
                width: 60,//按钮的长度
                handler: this.Delete       
              }]
           },{
                 dock: 'bottom',
                 xtype: 'pagingtoolbar',//分页条（位置在底端）
                 store: adminstore,//读取数据
                 displayInfo: true,
                 displayMsg: '显示 {0} - {1} 条，共计 {2} 条',//有数据时的显示格式
                 emptyMsg: '没有数据'     //没有数据时的显示
            }],
            
    });
    this.callParent(arguments);
    },
    
    /*创建store方法*/
    createStore: function(){
          adminstore = Ext.create('APP.store.AdminStore');//创建AdminStore对象
    },
    
    /*查找Admin方法*/
    Search: function(){
       var searchValue = this.getValue();//获取搜索框的值（这里的this是指triggerfield）
       Ext.MessageBox.alert('搜索当前的值',searchValue);
    },
    
    /*添加Admin方法*/
    Add: function(){
         Ext.require([
			    'Ext.form.*',
			    'Ext.window.Window'
			]);

		 Ext.onReady(function() {
		    var addform = Ext.create('Ext.form.Panel', {
		        border: false,
		        fieldDefaults: {
		            labelWidth: 35
		        },
		        defaultType: 'textfield',
		        bodyPadding: 5,
		
		        items: [{
		            fieldLabel: '账号',
		            name: 'account',
		            allowBlank:false,  //设置输入不能为空
		            blankText:'账号输入不能为空',
		            anchor:'100%'  // anchor width by percentage
		        },{
		            fieldLabel: '密码',
		            name: 'password',
		            allowBlank:false,  //设置输入不能为空
		            blankText:'密码输入不能为空',
		            anchor: '100%'  
		        },{
		            fieldLabel: '姓名',
		            name: 'name',
		            allowBlank:false,  //设置输入不能为空
		            blankText:'姓名输入不能为空',
		            anchor: '100%'  
		        }, {
		            xtype: 'numberfield',
		            fieldLabel: '年龄',
		            name: 'age',
		            value: '23',
		            minValue: '0',
		            maxValue: '50',
		            anchor: '100%' 
		        },{
                    xtype: 'combobox',
                    fieldLabel: '性别',
                    name: 'sex',
                    editable: false,
                    //readOnly:'true',
                    //draggable:'false',
                    store: Ext.create('Ext.data.ArrayStore', {
                        fields: ['sex'],
                        data : ['男','女'] 
                    }),
                    valueField: 'sex',
                    displayField: 'sex',
                    typeAhead: true,
                    queryMode: 'local',
                    emptyText: '男',
                    anchor: '100%'
                }, {
		            fieldLabel: '电话',
		            name: 'telphone',
		            allowBlank:false,  //设置输入不能为空
		            blankText:'电话输入不能为空',
		            anchor: '100%'  
		        }]
		    });
		
		    var win = Ext.create('Ext.window.Window', {
		        title: '管理员注册',
		        width: 200,
		        height:230,
		        minWidth: 300,
		        minHeight: 200,
		        iconCls: 'icon-login', 
		        layout: 'fit',
		        plain: true,
		        items: addform,
		
		        buttons: [{
		            text: '确定'
		        },{
		            text: '取消',
		            handler:function(){
		            win.hide();
		            },
		        }]
		    });
		    win.show();
		});
    },
    
    /*修改Admin方法*/
    Modify: function(){
         			    var s = admingrid.getSelectionModel().getSelection();
						if (s.length == 0) {// **************************************判断有没有选中行
							Ext.Msg.alert('提示', '你还没有选择要操作的记录!');
						} else {
							records = admingrid.getSelectionModel().getSelection();// *********记录选中行，row为数组
							Ext.require([
							    'Ext.form.*',
							    'Ext.window.Window'
							]);
				
						    Ext.onReady(function() {
						        modifyform = Ext.create('Ext.form.Panel', {
						        border: false,
						        fieldDefaults: {
						            labelWidth: 35
						        },
						        defaultType: 'textfield',
						        bodyPadding: 5,
						
						        items: [{
						            fieldLabel: '账号',
						            name: 'account',
						            allowBlank:false,  //设置输入不能为空
						            blankText:'账号输入不能为空',
						            value:records[0].get("Account"),//取得修改前的账号
						            anchor:'100%'  
						        },{
						            fieldLabel: '密码',
						            name: 'password',
						            allowBlank:false,  //设置输入不能为空
						            blankText:'密码输入不能为空',
						            value:records[0].get("Password"),//取得修改前的密码
						            anchor: '100%'  
						        },{
						            fieldLabel: '姓名',
						            name: 'name',
						            allowBlank:false,  //设置输入不能为空
						            blankText:'姓名输入不能为空',
						            value:records[0].get("Name"),//取得修改前的姓名
						            anchor: '100%'  
						        }, {
						            xtype: 'numberfield',
						            fieldLabel: '年龄',
						            name: 'age',
						            value:records[0].get("Age"),//取得修改前的年龄
						            minValue: '0',
						            maxValue: '50',
						            anchor: '100%'  
						        },{
				                    xtype: 'combobox',
				                    fieldLabel: '性别',
				                    name: 'sex',
				                    //editable:'false',
				                    //readOnly:'true',
				                    //draggable:'false',
				                    store: Ext.create('Ext.data.ArrayStore', {
				                        fields: ['sex'],
				                        data : ['男','女'] 
				                    }),
				                    valueField: 'sex',
				                    displayField: 'sex',
				                    typeAhead: true,
				                    queryMode: 'local',
				                    //emptyText: '男',
				                    value:records[0].get("Sex"),//取得修改前的性别
				                    anchor: '100%'
				                }, {
						            fieldLabel: '电话',
						            name: 'telphone',
						            allowBlank:false,  //设置输入不能为空
						            blankText:'电话输入不能为空',
						            value:records[0].get("Phone"),//取得修改前的电话
						            anchor: '100%'  
						        }]
						    });
						
						        modifywin = Ext.create('Ext.window.Window', {
						        title: '管理员信息修改',
						        width: 200,
						        height:230,
						        minWidth: 300,
						        minHeight: 200,
						        iconCls: 'icon-login', 
						        layout: 'fit',
						        plain: true,
						        items: modifyform,
						
						        buttons: [{
						            text: '确定'
						        },{
						            text: '取消',
						            handler:function(){
						            modifywin.hide();
						            },
						        }]
						    });
						    modifywin.show();
						});
						};
					},
    
    /*删除Admin方法*/
    Delete: function(){
        var records = admingrid.getSelectionModel().getSelection();//选中的记录集
        Ext.MessageBox.alert('显示选中记录的编号',records[0].get("Id")+"");       
    }

});
