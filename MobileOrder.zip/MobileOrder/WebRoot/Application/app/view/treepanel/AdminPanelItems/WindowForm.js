var sexstore = Ext.create('Ext.data.ArrayStore', {
                   fields: ['adm_sex'],
                   data: ['男','女'] 
});	
Ext.define('APP.view.treepanel.AdminPanelItems.WindowForm',{
    extend: 'Ext.form.Panel',
    initComponent : function(){
        Ext.apply(this,{
            border: false,
		    fieldDefaults: {
		    labelWidth: 35, //子项目的标签宽度
		    anchor:'100%'   //子项目的大小比例
		    },
		    defaultType: 'textfield', //默认子项目都为textfield
		    bodyPadding: 5,	//填充大小
		    items: [{
		             fieldLabel: '账号',
		             itemId: 'adm_account', //子项目的id号
		             name: 'adm_account',
		             allowBlank:false,  //设置输入不能为空
		             blankText:'账号输入不能为空'
		            }, {
		             fieldLabel: '密码',
		             itemId: 'adm_password',
		             name: 'adm_password',
		             allowBlank:false,  //设置输入不能为空
		             blankText:'密码输入不能为空'
		            }, {
		             fieldLabel: '姓名',
		             itemId: 'adm_name',
		             name: 'adm_name',
		             allowBlank:false,  //设置输入不能为空
		             blankText:'姓名输入不能为空'
		            }, {
		             xtype: 'numberfield',
		             fieldLabel: '年龄',
		             itemId: 'adm_age',
		             name: 'adm_age',
		             value: '23',
		             minValue: '15',
		             maxValue: '50'
		            }, {
                     xtype: 'combobox',
                     fieldLabel: '性别',
                     itemId: 'adm_sex',
                     name: 'adm_sex',
                     editable: false,
                     store: sexstore,
                     valueField: 'adm_sex',
                     displayField: 'adm_sex'
                    }, {
		             fieldLabel: '电话',
		             itemId: 'adm_phone', 
		             name: 'adm_phone',
		             allowBlank:false,  //设置输入不能为空
		             blankText:'电话输入不能为空'  
		           }]  
       });
       this.callParent(arguments);
    }
});