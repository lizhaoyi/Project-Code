var adminstore = {};//全局变量adminstore
var admingrid;
/*定义显示管理员信息的AdminGrid类*/
Ext.define('APP.view.treepanel.AdminPanelItems.AdminGrid' ,{
    extend: 'Ext.grid.Panel',
    requires: [
       'APP.store.AdminStore'
    ],
    initComponent : function(){
        admingrid = this;
        this.createStore();//创建gridPanel的store
        Ext.apply(this,{
            store: adminstore,//设置grid的store
            border: false,//设置grid没边框
            /*显示grid的列名*/
            columns: [
                {text: '编号', width: 120, dataIndex: 'Id', sortable: true},
                {text: '姓名', width: 120, dataIndex: 'Name', sortable: false},
                {text: '性别', width: 90, dataIndex: 'Sex', sortable: true},
                {text: '账号', width: 150, dataIndex: 'Account', sortable: true},
                {text: '密码', width: 150, dataIndex: 'Password', sortable: false},
                {text: '年龄', width: 120, dataIndex: 'Age', sortable: true},
                {text: '电话', flex: 1, dataIndex: 'Phone', sortable: false}        
            ],    	
	        dockedItems: [ {
            dock: 'top',
            xtype: 'toolbar',//工具条（位置在顶端）
            items: ['搜 索：',{
                xtype: 'triggerfield',
                width: 120,//搜索条的长度
                triggerCls: 'x-form-search-trigger',
                onTriggerClick: this.Search
              },'->',{
                xtype: 'button',
                text: '添加',
                cls: 'admin-add',//按钮的CSS
                width: 60,//按钮的长度
                handler: this.Add
              },'-',{
                xtype: 'button',
                text: '修改',
                cls: 'admin-modify',//按钮的CSS
                width: 60,//按钮的长度
                handler: this.Modify
              },'-',{
                xtype: 'button',
                text: '删除',
                cls: 'admin-delete',//按钮的CSS
                width: 60,//按钮的长度
                handler: this.Delete       
              }]
           },{
                 dock: 'bottom',
                 xtype: 'pagingtoolbar',//分页条（位置在底端）
                 store: adminstore,//读取数据
                 displayInfo: true,
                 displayMsg: '显示 {0} - {1} 条，共计 {2} 条',//有数据时的显示格式
                 emptyMsg: '没有数据'     //没有数据时的显示
            }],
            
    });
    this.callParent(arguments);
    },
    
    /*创建store方法*/
    createStore: function(){
          adminstore = Ext.create('APP.store.AdminStore');//创建AdminStore对象
    },
    
    /*查找Admin方法*/
    Search: function(){
       var searchValue = this.getValue();//获取搜索框的值（这里的this是指triggerfield）
       Ext.MessageBox.alert('搜索当前的值',searchValue);
    },
    
    /*添加Admin方法*/
    Add: function(){
         Ext.MessageBox.alert('提示','该方法还未编写！');
    },
    
    /*修改Admin方法*/
    Modify: function(){
         Ext.MessageBox.alert('提示','该方法还未编写！');
    },
    
    /*删除Admin方法*/
    Delete: function(){
        var records = admingrid.getSelectionModel().getSelection();//选中的记录集
        Ext.MessageBox.alert('显示选中记录的编号',records[0].get("Id")+"");       
    }

});
