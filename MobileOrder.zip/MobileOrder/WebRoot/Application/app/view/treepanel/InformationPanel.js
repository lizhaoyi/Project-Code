//定义信息管理的panel
Ext.define('APP.view.treepanel.InformationPanel',{
    extend: 'Ext.panel.Panel',
    initComponent : function(){
        Ext.apply(this,{
            id: 'information-panel',
            title: '信息管理',
            iconCls: 'icon-informationManagement-16',
            layout: 'fit',
            html: '<h1>界面未编写</h1>'
       });
       this.callParent(arguments);
    }
});