//定义主页的panel
Ext.define('APP.view.treepanel.HomePanel',{
    extend: 'Ext.panel.Panel',
        requires: [ 
       'APP.view.window.loginWindow'
    ],
    initComponent : function(){
        Ext.apply(this,{
            id: 'home-panel',
            title: '首页',
            iconCls:'icon-home-16',
            layout: 'fit',
            items: Ext.create('APP.view.window.loginWindow').show()//创建loginWindow
       });
       this.callParent(arguments);
    }
});