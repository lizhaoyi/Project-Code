//定义主页的panel
Ext.define('APP.view.treepanel.HomePanel',{
    extend: 'Ext.panel.Panel',
    initComponent : function(){
        Ext.apply(this,{
            id: 'home-panel',
            title: '首页',
            iconCls:'icon-home-16',
            layout: 'fit',
            html: '<h1>欢迎进入点餐系统后台</h1>'
       });
       this.callParent(arguments);
    }
});