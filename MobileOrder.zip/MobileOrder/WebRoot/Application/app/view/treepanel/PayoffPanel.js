//定义支付管理的panel
Ext.define('APP.view.treepanel.PayoffPanel',{
    extend: 'Ext.panel.Panel',
    initComponent : function(){
        Ext.apply(this,{
            id: 'payoff-panel',
            title: '支付管理',
            iconCls: 'icon-payoffManagement-16',
            layout: 'fit',
            html: '<h1>界面未编写</h1>'
       });
       this.callParent(arguments);
    }
});