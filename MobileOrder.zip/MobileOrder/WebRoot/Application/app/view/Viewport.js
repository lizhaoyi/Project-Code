//定义后台框架的整体视图Viewport类
Ext.define('APP.view.Viewport',{
    extend: 'Ext.container.Viewport',
    layout: 'fit',
    hideBorders: true,
    requires: [
       'APP.view.Header',
       'APP.view.Menu',
       'APP.view.ContentPanel',
       'APP.view.Bottom'
    ], 
    initComponent : function(){
        var me = this;
        Ext.apply(me, {
            items: [{
               id: 'desk',
               layout: 'border',
               items: [
                  Ext.create('APP.view.Header'),
                  Ext.create('APP.view.Menu'),
                  Ext.create('APP.view.ContentPanel'),
                  Ext.create('APP.view.Bottom')
               ]
            }]
       });
       me.callParent(arguments);
    }
});
