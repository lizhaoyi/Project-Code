//定义后台框架顶端的Header类
Ext.define('APP.view.Header', {
    extend: 'Ext.Component',
    //初始化Header类
    initComponent: function() {
        Ext.applyIf(this, {
            xtype: 'box',
            id: 'header',
            cls: 'header',                  //设置class值
            region: 'north',
            html: '<h1>移动订餐系统后台</h1>', //标题的题目
            height: 30
        });
            this.callParent(arguments);
   }
});
