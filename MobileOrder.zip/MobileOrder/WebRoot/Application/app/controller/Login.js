//定义登录控制器类Login
Ext.define('APP.controller.Login',{
    extend: 'Ext.app.Controller',
    requires:['APP.view.window.loginWindow'],  //引入App.view.window.loginWindow类
    init : function(){
      //创建App.view.window.loginWindow对象
      Ext.create('APP.view.window.loginWindow').show();
    }
});