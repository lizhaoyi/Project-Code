//定义主要控制器类Main
Ext.define('APP.controller.Main',{
    extend: 'Ext.app.Controller',
    models: ['Admin'],
    requires:['APP.view.Viewport'],  //引入App.view.Viewport类
    init : function(){
      //创建App.view.Viewport对象
      Ext.create('APP.view.Viewport');
    }
});