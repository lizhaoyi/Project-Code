-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.15


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema mobileorder
--

CREATE DATABASE IF NOT EXISTS mobileorder;
USE mobileorder;

--
-- Definition of table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `adm_autoid` int(11) NOT NULL AUTO_INCREMENT,
  `adm_account` varchar(20) NOT NULL,
  `adm_password` varchar(20) NOT NULL,
  `adm_name` varchar(20) NOT NULL,
  `adm_sex` varchar(2) NOT NULL,
  `adm_age` varchar(20) NOT NULL,
  `adm_phone` varchar(20) NOT NULL,
  `flag` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`adm_autoid`),
  UNIQUE KEY `adm_account` (`adm_account`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`adm_autoid`,`adm_account`,`adm_password`,`adm_name`,`adm_sex`,`adm_age`,`adm_phone`,`flag`) VALUES 
 (1,'lebron','23','詹姆斯','男','23','15820707035',1),
 (2,'james','6','勒布朗','男','27','13465233256',1),
 (3,'lbj','6','皇帝','男','25','13614523698',1);
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
